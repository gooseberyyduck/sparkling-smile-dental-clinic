import { useState } from "react";



import { Link } from "react-router-dom";
import Seo from "../components/Seo";
import { dentistSchema } from "../seo/site";



type Service = {



  id: number;



  name: string;



  slug: string;



  category: string;



  short_description: string | null;



  duration_minutes: number;



  price: number | string | null;



  image: string | null;



};







const STATIC_SERVICES: Service[] = [
  { id: 1, name: "Root Canal Treatment", slug: "root-canal-treatment", category: "Root Canal Treatment", short_description: "Treatment to address infection or damage inside a tooth and help preserve the natural tooth.", duration_minutes: 30, price: null, image: null },
  { id: 2, name: "Re-Root Canal Treatment", slug: "re-root-canal-treatment", category: "Root Canal Treatment", short_description: "Specialised treatment for teeth that require a repeat root canal procedure.", duration_minutes: 30, price: null, image: null },
  { id: 3, name: "Single Sitting Root Canal Treatment", slug: "single-sitting-root-canal-treatment", category: "Root Canal Treatment", short_description: "Root canal treatment planned for completion in one visit when clinically suitable.", duration_minutes: 30, price: null, image: null },
  { id: 4, name: "Calcified Root Canal Treatment", slug: "calcified-root-canal-treatment", category: "Root Canal Treatment", short_description: "Specialised treatment for root canals affected by calcification.", duration_minutes: 30, price: null, image: null },
  { id: 5, name: "Wisdom Tooth Root Canal Treatment", slug: "wisdom-tooth-root-canal-treatment", category: "Root Canal Treatment", short_description: "Assessment and treatment of suitable wisdom teeth affected by internal infection.", duration_minutes: 30, price: null, image: null },
  { id: 6, name: "Post and Core", slug: "post-and-core", category: "Restorative Dentistry", short_description: "A restorative procedure used to support and rebuild a damaged tooth.", duration_minutes: 30, price: null, image: null },
  { id: 7, name: "General Dentistry", slug: "general-dentistry", category: "General Dentistry", short_description: "General dental examinations, diagnosis and routine dental care.", duration_minutes: 30, price: null, image: null },
  { id: 8, name: "Dental Cleaning", slug: "dental-cleaning", category: "General Dentistry", short_description: "Professional cleaning to remove plaque and tartar buildup.", duration_minutes: 30, price: null, image: null },
  { id: 9, name: "Scaling and Polishing", slug: "polishing", category: "General Dentistry", short_description: "Professional scaling and polishing to remove plaque and tartar and smooth tooth surfaces.", duration_minutes: 30, price: null, image: null },
  { id: 10, name: "Dental Filling", slug: "dental-filling", category: "Restorative Dentistry", short_description: "Restoration of teeth affected by cavities or minor damage.", duration_minutes: 30, price: null, image: null },
  { id: 11, name: "Tooth Extraction", slug: "tooth-extraction", category: "Oral Surgery", short_description: "Removal of a tooth when extraction is considered necessary.", duration_minutes: 30, price: null, image: null },
  { id: 12, name: "Dental Surgery", slug: "dental-surgery", category: "Oral Surgery", short_description: "Dental surgical procedures following clinical assessment.", duration_minutes: 30, price: null, image: null },
  { id: 13, name: "Dental Veneers", slug: "dental-veneers", category: "Cosmetic Dentistry", short_description: "Custom dental coverings designed to improve the appearance of teeth.", duration_minutes: 30, price: null, image: null },
  { id: 14, name: "Digital Smile Design", slug: "digital-smile-design", category: "Cosmetic Dentistry", short_description: "Digital planning to help visualise a proposed smile enhancement.", duration_minutes: 30, price: null, image: null },
  { id: 15, name: "Hollywood Smile", slug: "hollywood-smile", category: "Cosmetic Dentistry", short_description: "A customised cosmetic dental treatment plan for smile enhancement.", duration_minutes: 30, price: null, image: null },
  { id: 16, name: "Snap-On Smile", slug: "snap-on-smile", category: "Cosmetic Dentistry", short_description: "A removable cosmetic dental appliance designed to improve smile appearance.", duration_minutes: 30, price: null, image: null },
  { id: 17, name: "Dental Jewellery", slug: "dental-jewellery", category: "Cosmetic Dentistry", short_description: "A cosmetic dental accessory applied to enhance the appearance of a smile.", duration_minutes: 30, price: null, image: null },
  { id: 18, name: "Teeth Whitening", slug: "teeth-whitening", category: "Cosmetic Dentistry", short_description: "Professional treatment to improve the shade of discoloured teeth.", duration_minutes: 30, price: null, image: null },
  { id: 19, name: "Crowns and Bridges", slug: "crowns-bridges", category: "Restorative Dentistry", short_description: "Dental restorations used to protect damaged teeth and replace missing teeth.", duration_minutes: 30, price: null, image: null },
  { id: 20, name: "Flexible Denture", slug: "flexible-denture", category: "Restorative Dentistry", short_description: "A flexible removable dental appliance used to replace missing teeth.", duration_minutes: 30, price: null, image: null },
  { id: 21, name: "Acrylic Denture", slug: "acrylic-denture", category: "Restorative Dentistry", short_description: "A removable acrylic appliance designed to replace missing teeth.", duration_minutes: 30, price: null, image: null },
  { id: 22, name: "Gum Disease Treatment", slug: "gum-disease-treatment", category: "General Dentistry", short_description: "Assessment and treatment of gum inflammation and periodontal problems.", duration_minutes: 30, price: null, image: null },
  { id: 23, name: "Fluoride Treatment", slug: "fluoride-treatment", category: "Preventive Dentistry", short_description: "A preventive treatment that helps strengthen tooth enamel.", duration_minutes: 30, price: null, image: null },
  { id: 24, name: "Dental X-Ray", slug: "dental-x-ray", category: "Diagnostic Dentistry", short_description: "Dental imaging to help assess teeth and surrounding structures.", duration_minutes: 30, price: null, image: null },
  { id: 25, name: "Tooth Sensitivity Management", slug: "tooth-sensitivity-management", category: "General Dentistry", short_description: "Assessment and care for teeth affected by sensitivity.", duration_minutes: 30, price: null, image: null },
  { id: 26, name: "Pediatric Dentistry", slug: "pediatric-dentistry", category: "General Dentistry", short_description: "Child-friendly dental check-ups, preventive care and treatment for children in Abu Dhabi.", duration_minutes: 30, price: null, image: null },
  { id: 27, name: "Cosmetic Dentistry", slug: "cosmetic-dentistry", category: "Cosmetic Dentistry", short_description: "Smile enhancement treatments such as whitening, veneers, bonding and contouring.", duration_minutes: 30, price: null, image: null },
];

const ROOT_CANAL_FALLBACK: Service = {



  id: -1,



  name: "Root Canal Treatment",



  slug: "root-canal-treatment",



  category: "Root Canal Treatment",



  short_description: null,



  duration_minutes: 30,



  price: null,



  image: null,



};



/* ==========================================================



   CHOOSE THE MOST RELEVANT AVAILABLE SERVICE IMAGE



   ========================================================== */



function getServiceImage(service: Service): string {



  if (service.image?.trim()) {



    const image = service.image.trim();



    if (/^https?:\/\//i.test(image) || image.startsWith("/")) {



      return image;



    }



    if (image.startsWith("images/")) {



      return `/${image}`;



    }



    return `/images/${image}`;



  }



  const slug = service.slug.toLowerCase();



  const text =



    `${service.name} ${service.category} ${service.slug}`.toLowerCase();



  // Unique cosmetic dentistry images



  const uniqueImages: Record<string, string> = {



    "dental-jewellery": "dental-jewellery.webp",



    "dental-veneers": "dental-veneers.webp",



    "digital-smile-design": "digital-smile-design.webp",



    "hollywood-smile": "hollywood-smile.webp",



    "snap-on-smile": "snap-on-smile.webp",



    "teeth-whitening": "teeth-whitening.webp",



    "dental-whitening": "teeth-whitening.webp",



    "dental-crown": "dental-crown.webp",



    "dental-bridges": "dental-bridges.webp",



    "crowns-bridges": "crowns-bridges.webp",



    "flexible-denture": "flexible-denture.webp",



    "acrylic-denture": "acrylic-denture.webp",



    "dental-cleaning": "dental-cleaning.webp",



    "dental-filling": "dental-filling.webp",



    "fluoride-treatment": "fluoride-treatment.webp",



    "gum-disease-treatment": "gum-disease-treatment.webp",



    "dental-x-ray": "dental-x-ray.webp",



    "tooth-sensitivity-management": "tooth-sensitivity.webp",



    "general-dentistry": "general-dentistry.webp",



    "tooth-extraction": "tooth-extraction.webp",



    "dental-surgery": "dental-surgery.webp",



    "pediatric-dentistry": "pediatric-dentistry.webp",



    "prosthodontics": "prosthodontics.webp",



    "polishing": "dental-polishing.webp",
    "cosmetic-dentistry": "hollywood-smile.webp",



    "re-root-canal-treatment": "re-root-canal.webp",



    "root-canal-treatment": "root-canal.webp",



    "single-sitting-root-canal-treatment": "single-sitting-root-canal.webp",



    "calcified-root-canal-treatment": "calcified-root-canal.webp",



    "wisdom-tooth-root-canal-treatment": "wisdom-tooth-root-canal.webp",



    "post-and-core": "post-and-core.webp",



  };



  // Match exact service slugs before using category fallbacks



  if (uniqueImages[slug]) {



    return `/images/services/${uniqueImages[slug]}`;



  }



  // Relevant fallback images for additional services



  if (text.includes("root canal")) {



    return "/images/services/root-canal.webp";



  }



  if (text.includes("cleaning")) {



    return "/images/services/dental-cleaning.webp";



  }



  if (text.includes("polishing")) {



    return "/images/services/dental-polishing.webp";



  }



  if (text.includes("whitening")) {



    return "/images/services/teeth-whitening.webp";



  }



  if (text.includes("veneer")) {



    return "/images/services/dental-veneers.webp";



  }



  if (text.includes("jewellery")) {



    return "/images/services/dental-jewellery.webp";



  }



  if (text.includes("smile")) {



    return "/images/services/hollywood-smile.webp";



  }



  if (text.includes("crown") || text.includes("bridge")) {



    return "/images/services/crowns-bridges.webp";



  }



  if (text.includes("denture")) {



    return "/images/services/flexible-denture.webp";



  }



  if (text.includes("extraction") || text.includes("surgery")) {



    return "/images/services/dental-surgery.webp";



  }



  if (text.includes("pediatric")) {



    return "/images/services/pediatric-dentistry.webp";



  }



  if (text.includes("gum")) {



    return "/images/services/gum-disease-treatment.webp";



  }



  if (text.includes("fluoride")) {



    return "/images/services/fluoride-treatment.webp";



  }



  if (text.includes("x-ray")) {



    return "/images/services/dental-x-ray.webp";



  }



  if (text.includes("filling")) {



    return "/images/services/dental-filling.webp";



  }



  if (text.includes("prosthodontic")) {



    return "/images/services/prosthodontics.webp";



  }



  return "/images/services/general-dentistry.webp";



}



/* ==========================================================



   CLEAN SVG FALLBACKS



   Used only when a service photo is unavailable.



   ========================================================== */



function ServiceIcon({ service }: { service: Service }) {



  const text =



    `${service.name} ${service.category}`.toLowerCase();



  if (text.includes("root canal")) {



    return (



      <svg viewBox="0 0 48 48" aria-hidden="true">



        <path



          d="M14 8C8 9 7 17 10 24L17 41C18 44 21 43 22 39L24 29L27 39C28 43 31 44 33 40L39 23C42 14 36 7 30 9C27 10 25 12 22 11C19 11 17 8 14 8Z"



          fill="none"



          stroke="currentColor"



          strokeWidth="2.2"



          strokeLinejoin="round"



        />



        <path



          d="M24 15V24M20 20L24 24L28 20"



          fill="none"



          stroke="currentColor"



          strokeWidth="2"



          strokeLinecap="round"



          strokeLinejoin="round"



        />



      </svg>



    );



  }



  if (



    text.includes("cleaning") ||



    text.includes("polishing") ||



    text.includes("whitening") ||



    text.includes("cosmetic") ||



    text.includes("veneer")



  ) {



    return (



      <svg viewBox="0 0 48 48" aria-hidden="true">



        <path



          d="M20 7L23 17L33 20L23 23L20 33L17 23L7 20L17 17Z"



          fill="none"



          stroke="currentColor"



          strokeWidth="2.2"



          strokeLinejoin="round"



        />



        <path



          d="M35 27L37 33L43 35L37 37L35 43L33 37L27 35L33 33Z"



          fill="none"



          stroke="currentColor"



          strokeWidth="2"



          strokeLinejoin="round"



        />



      </svg>



    );



  }



  if (



    text.includes("surgery") ||



    text.includes("extraction")



  ) {



    return (



      <svg viewBox="0 0 48 48" aria-hidden="true">



        <circle



          cx="24"



          cy="24"



          r="17"



          fill="none"



          stroke="currentColor"



          strokeWidth="2.2"



        />



        <path



          d="M24 15V33M15 24H33"



          fill="none"



          stroke="currentColor"



          strokeWidth="2.5"



          strokeLinecap="round"



        />



      </svg>



    );



  }



  if (



    text.includes("crown") ||



    text.includes("bridge") ||



    text.includes("denture") ||



    text.includes("prosthodont")



  ) {



    return (



      <svg viewBox="0 0 48 48" aria-hidden="true">



        <path



          d="M9 15L17 20L24 13L31 20L39 15L35 38H13Z"



          fill="none"



          stroke="currentColor"



          strokeWidth="2.2"



          strokeLinejoin="round"



        />



        <path



          d="M15 28H33"



          fill="none"



          stroke="currentColor"



          strokeWidth="2"



          strokeLinecap="round"



        />



      </svg>



    );



  }



  return (



    <svg viewBox="0 0 48 48" aria-hidden="true">



      <path



        d="M14 8C8 9 7 17 10 24L17 41C18 44 21 43 22 39L24 29L27 39C28 43 31 44 33 40L39 23C42 14 36 7 30 9C27 10 25 12 22 11C19 11 17 8 14 8Z"



        fill="none"



        stroke="currentColor"



        strokeWidth="2.2"



        strokeLinejoin="round"



      />



    </svg>



  );



}



/* ==========================================================



   SERVICE PHOTO



   If a photo is missing, show a clean SVG icon instead.



   ========================================================== */



function ServiceVisual({



  service,



  className,



}: {



  service: Service;



  className: string;



}) {



  const [imageFailed, setImageFailed] = useState(false);



  const imagePath = getServiceImage(service);



  if (imageFailed) {



    return (



      <div



        className={`${className} service-image-fallback`}



        role="img"



        aria-label={`${service.name} illustration`}



      >



        <span className="service-fallback-icon">



          <ServiceIcon service={service} />



        </span>



      </div>



    );



  }



  return (



    <img



      className={className}



      src={imagePath}



      alt={`${service.name} at Sparkling Smile Dental Clinic`}



      loading="lazy"



      onError={() => setImageFailed(true)}



    />



  );



}



/* ==========================================================



   CATEGORY ORDER



   Root canal services always appear first.



   ========================================================== */



function categoryPriority(category: string): number {



  const value = category.toLowerCase();



  if (value.includes("root canal")) return 0;



  if (value.includes("general") || value.includes("preventive")) return 1;



  if (value.includes("cosmetic")) return 2;



  if (value.includes("restorative") || value.includes("prosthodontic")) return 3;



  if (value.includes("surgery") || value.includes("pediatric")) return 4;



  return 5;



}



function Services() {



  const [services] = useState<Service[]>(STATIC_SERVICES);
  const loading = false;
  const error = "";



  const rootCanalService =



    services.find(



      (service) =>



        service.slug.toLowerCase().includes("root-canal-treatment") &&



        !service.name.toLowerCase().includes("re-root")



    ) ||



    services.find(



      (service) =>



        service.name.toLowerCase() === "root canal treatment"



    );



  const featuredRootCanal =



    rootCanalService || ROOT_CANAL_FALLBACK;



  const featuredSlug =



    rootCanalService?.slug || "root-canal-treatment";



  const relatedRootCanalServices = services.filter(



    (service) =>



      service.slug !== featuredSlug &&



      `${service.name} ${service.category} ${service.slug}`



        .toLowerCase()



        .includes("root canal")



  );



  const groupedServices = services.reduce(



    (groups, service) => {



      if (!groups[service.category]) {



        groups[service.category] = [];



      }



      groups[service.category].push(service);



      return groups;



    },



    {} as Record<string, Service[]>



  );



  const orderedCategories = Object.entries(groupedServices).sort(



    ([categoryA], [categoryB]) =>



      categoryPriority(categoryA) - categoryPriority(categoryB) ||



      categoryA.localeCompare(categoryB)



  );



  return (
    <div className="site">
      <Seo
        title="Dental Services in Abu Dhabi | Root Canal, Cosmetic & General Dentistry"
        description="Explore dental treatments at Sparkling Smile Dental Clinic, Al Zahiyah, Abu Dhabi: root canal, cleaning, fillings, crowns, veneers, teeth whitening, dentures and more."
        path="/services"
        schema={dentistSchema}
      />



      {/* NAVBAR */}



      <header className="navbar">



        <div className="container navbar-inner">



          <Link to="/" className="brand">



            <img



              src="/images/sparkling-smile-logo.webp" width="160" height="155"



              alt="Sparkling Smile Dental Clinic"



              className="brand-logo-image"



            />



            <div className="brand-text">



              <span className="brand-name">



                SPARKLING SMILE



              </span>



              <span className="brand-tagline">



                Dental Clinic



              </span>



            </div>



          </Link>



          <nav className="nav-links">



            <Link to="/">Home</Link>



            <Link to="/services">Services</Link>



            <Link to="/#about">About</Link>



            <Link to="/#team">Our Team</Link>



            <Link to="/#gallery">Gallery</Link>



            <Link to="/#contact">Contact</Link>



          </nav>



          <a href="https://wa.me/971503002504" target="_blank" rel="noopener noreferrer" className="nav-button">



            Book Appointment



          </a>



        </div>



      </header>



      {/* SERVICES HERO */}



      <section className="service-page-hero">



        <div className="container">



          <p className="eyebrow">OUR SERVICES</p>



          <h1>



            Comprehensive care for



            <br />



            every smile.



          </h1>



          <p>



            Explore the dental treatments available at



            Sparkling Smile Dental Clinic, with a special



            focus on root canal care.



          </p>



          <a



            href="https://wa.me/971503002504" target="_blank" rel="noopener noreferrer"



            className="primary-button service-hero-book"



          >



            Book Appointment



          </a>



        </div>



      </section>



      {/* SERVICES CONTENT */}



      <main className="section">



        <div className="container">



          {loading && (



            <div className="loading-message">



              Loading services...



            </div>



          )}



          {error && (



            <div className="error-message">



              {error}



            </div>



          )}



          {!loading && !error && (



            <>



              {/* ROOT CANAL SPECIALTY FEATURE */}



              <section



                className="service-specialty-section"



                aria-labelledby="root-canal-heading"



              >



                <div className="root-canal-feature">



                  <div className="root-canal-feature-media">



                    <ServiceVisual



                      service={featuredRootCanal}



                      className="root-canal-feature-image"



                    />



                    <span className="root-canal-image-label">



                      Our Specialty



                    </span>



                  </div>



                  <div className="root-canal-feature-content">



                    <p className="eyebrow">



                      OUR FEATURED SPECIALTY



                    </p>



                    <h2 id="root-canal-heading">



                      Root Canal Treatment



                    </h2>



                    <p>



                      Root canal treatment focuses on problems



                      affecting the inner part of a tooth. After



                      an assessment, the dentist can explain the



                      appropriate treatment options and whether



                      the natural tooth can be preserved.



                    </p>



                    <p>



                      Explore our root canal treatment options



                      and book a consultation to discuss your



                      dental concerns.



                    </p>



                    <div className="root-canal-related">



                      {relatedRootCanalServices



                        .slice(0, 4)



                        .map((service) => (



                          <Link



                            key={service.id}



                            to={`/services/${service.slug}`}



                            className="root-canal-related-link"



                          >



                            {service.name}



                            <span aria-hidden="true"> ↗</span>



                          </Link>



                        ))}



                    </div>



                    <div className="root-canal-feature-actions">



                      <a



                        href="https://wa.me/971503002504" target="_blank" rel="noopener noreferrer"



                        className="primary-button"



                      >



                        Book Appointment



                      </a>



                      <Link



                        to={`/services/${featuredSlug}`}



                        className="service-featured-details"



                      >



                        Explore Treatment Details →



                      </Link>



                    </div>



                  </div>



                </div>



              </section>



              {/* ALL SERVICE CATEGORIES */}



              {orderedCategories.map(



                ([category, categoryServices]) => {



                  /*



                   * The featured root canal treatment is presented



                   * above. Keep the related procedures in this grid.



                   */



                  const hiddenServices = [



                    "pediatric dentistry",












                    "prosthodontics",



                    "hollywood smile",



                  ];



                  const visibleServices = categoryServices



                    .filter((service) => {



                      const searchableService = `${service.name} ${service.slug} ${service.category}`



                        .toLowerCase()



                        .replace(/&/g, "and")



                        .replace(/-/g, " ");



                      return (



                        service.slug !== featuredSlug &&



                        !hiddenServices.some((name) =>



                          searchableService.includes(name)



                        )



                      );



                    })



                    .sort((a, b) => {



                      const aIsRootCanal =



                        `${a.name} ${a.slug}`



                          .toLowerCase()



                          .includes("root canal");



                      const bIsRootCanal =



                        `${b.name} ${b.slug}`



                          .toLowerCase()



                          .includes("root canal");



                      if (aIsRootCanal && !bIsRootCanal) return -1;



                      if (!aIsRootCanal && bIsRootCanal) return 1;



                      return a.name.localeCompare(b.name);



                    });



                  if (visibleServices.length === 0) {



                    return null;



                  }



                  return (



                    <section



                      className="service-category"



                      key={category}



                    >



                      <div className="section-heading">



                        <p className="eyebrow">



                          {category.toUpperCase()}



                        </p>



                        <h2>{category}</h2>



                      </div>



                      <div className="services-grid">



                        {visibleServices.map((service) => (



                          <article



                            className="service-card"



                            key={service.id}



                          >



                            <div className="service-card-media-wrap">



                              <ServiceVisual



                                service={service}



                                className="service-card-media"



                              />



                            </div>



                            <h3>{service.name}</h3>



                            <p>



                              {service.short_description ||



                                "Professional dental care tailored to your individual needs."}



                            </p>



                            <div className="service-card-actions">



                              <Link



                                to={`/services/${service.slug}`}



                                className="service-card-link"



                              >



                                View Treatment Details →



                              </Link>



                              <a



                                href="https://wa.me/971503002504" target="_blank" rel="noopener noreferrer"



                                className="service-mini-book"



                              >



                                Book Appointment



                              </a>



                            </div>



                          </article>



                        ))}



                      </div>



                    </section>



                  );



                }



              )}



              {/* BOTTOM BOOKING CTA */}



              <section className="services-bottom-cta">



                <div>



                  <p className="eyebrow">



                    YOUR NEXT STEP



                  </p>



                  <h2>



                    Let’s talk about your dental health.



                  </h2>



                  <p>



                    Schedule a consultation so the dentist can



                    understand your needs and discuss suitable



                    treatment options.



                  </p>



                </div>



                <a



                  href="https://wa.me/971503002504" target="_blank" rel="noopener noreferrer"



                  className="primary-button"



                >



                  Book Appointment



                </a>



              </section>



            </>



          )}



        </div>



      </main>



      {/* FOOTER */}



      <footer className="footer">



        <div className="container footer-inner">



          <div>



            <strong>



              SPARKLING SMILE DENTAL CLINIC



            </strong>



            <p>



              Professional dental care for every smile.



            </p>



          </div>



          <div className="footer-links">



            <Link to="/">Home</Link>



            <Link to="/services">Services</Link>



            <Link to="/#about">About</Link>



            <Link to="/#contact">Contact</Link>



            <a href="https://wa.me/971503002504" target="_blank" rel="noopener noreferrer">Book Appointment</a>



          </div>



        </div>



        <div className="container copyright">



          © {new Date().getFullYear()} Sparkling Smile Dental Clinic.



          All rights reserved.



        </div>



      </footer>



    </div>



  );



}



export default Services;
